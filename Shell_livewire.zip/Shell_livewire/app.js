const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const session = require('express-session'); 
const dotenv = require('dotenv'); 

dotenv.config(); 

const app = express();
const port = process.env.PORT || 3000; 

const authRoutes = require('./routes/auth');
const leaveRoutes = require('./routes/leave');
const Leave = require('./models/Leave');
const User = require('./models/User'); 

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(session({
  secret: process.env.SESSION_SECRET || 'default_secret_key', 
  resave: false,
  saveUninitialized: false
}));

async function ensureAuthenticated(req, res, next) {
  if (req.session && req.session.userId) {
    try {
      const user = await User.findById(req.session.userId);
      if (!user) {
        return res.redirect('/auth/login'); 
      }
      req.user = user; 
      next(); 
    } catch (err) {
      console.error('Error finding user:', err);
      return res.redirect('/auth/login'); 
    }
  } else {
    res.redirect('/auth/login'); 
  }
}

app.get('/leave-status', ensureAuthenticated, async (req, res) => {
  try {
    let leaves;

    if (['Director', 'HR'].includes(req.user.position)) {
      
      leaves = await Leave.find({});
    } else {
      
      leaves = await Leave.find({ userId: req.user._id });
    }

    res.render('leave-status', { leaves, user: req.user });
  } catch (err) {
    console.error('Error fetching leave status:', err);
    res.status(500).send('Error fetching leave status');
  }
});

app.post('/approve-leave/:id', ensureAuthenticated, async (req, res) => {
  try {
    
    if (['Director', 'HR'].includes(req.user.position)) {
      const leave = await Leave.findById(req.params.id);
      if (!leave) {
        return res.status(404).send('Leave request not found');
      }

      await Leave.findByIdAndUpdate(req.params.id, { status: 'Approved' });
      res.redirect('/leave-status'); 
    } else {
      res.status(403).send('Unauthorized action');
    }
  } catch (err) {
    console.error('Error approving leave:', err);
    res.status(500).send('Error approving leave');
  }
});


app.post('/reject-leave/:id', ensureAuthenticated, async (req, res) => {
  try {
    
    if (['Director', 'HR'].includes(req.user.position)) {
      const leave = await Leave.findById(req.params.id);
      if (!leave) {
        return res.status(404).send('Leave request not found');
      }

      await Leave.findByIdAndUpdate(req.params.id, { status: 'Rejected' });
      res.redirect('/leave-status'); 
    } else {
      res.status(403).send('Unauthorized action');
    }
  } catch (err) {
    console.error('Error rejecting leave:', err);
    res.status(500).send('Error rejecting leave');
  }
});

app.use('/auth', authRoutes); 
app.use('/', leaveRoutes); 

app.get('/homepage', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'homepage.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/profile', ensureAuthenticated, (req, res) => {
  res.render('profile', { user: req.user });
});

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/leavemanagement', { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
})
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((err) => {
    console.error('Error connecting to MongoDB', err);
    process.exit(1); 
  });


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
