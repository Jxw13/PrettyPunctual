const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const session = require('express-session'); // For session management
const dotenv = require('dotenv'); // For loading environment variables

dotenv.config(); // Load environment variables from a .env file

const app = express();
const port = process.env.PORT || 3000; // Use the PORT from environment variables

const authRoutes = require('./routes/auth');
const leaveRoutes = require('./routes/leave');
const Leave = require('./models/Leave');
const User = require('./models/User'); // Assuming a User model exists

// Middleware to parse request bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Session setup with secret key from environment variables
app.use(session({
  secret: process.env.SESSION_SECRET || 'default_secret_key', // Use environment variable for production
  resave: false,
  saveUninitialized: false
}));

// Middleware to check if the user is authenticated
async function ensureAuthenticated(req, res, next) {
  if (req.session && req.session.userId) {
    try {
      const user = await User.findById(req.session.userId);
      if (!user) {
        return res.redirect('/auth/login'); // Redirect to login if user not found
      }
      req.user = user; // Attach user data to req.user
      next(); // Proceed to next middleware/route
    } catch (err) {
      console.error('Error finding user:', err);
      return res.redirect('/auth/login'); // Redirect to login in case of error
    }
  } else {
    res.redirect('/auth/login'); // Redirect to login if no session
  }
}

// Route to display leave status for the logged-in user (or all for HR/Directors)
app.get('/leave-status', ensureAuthenticated, async (req, res) => {
  try {
    let leaves;

    if (['Director', 'HR'].includes(req.user.position)) {
      // Directors/HR can see all leave applications
      leaves = await Leave.find({});
    } else {
      // Employees can only see their own leave applications
      leaves = await Leave.find({ userId: req.user._id });
    }

    // Render leave-status page with filtered leave data
    res.render('leave-status', { leaves, user: req.user });
  } catch (err) {
    console.error('Error fetching leave status:', err);
    res.status(500).send('Error fetching leave status');
  }
});

// Approve leave route (for Director/HR only)
app.post('/approve-leave/:id', ensureAuthenticated, async (req, res) => {
  try {
    // Ensure the logged-in user is authorized to approve leaves (Director/HR)
    if (['Director', 'HR'].includes(req.user.position)) {
      const leave = await Leave.findById(req.params.id);
      if (!leave) {
        return res.status(404).send('Leave request not found');
      }

      // Update leave status to 'Approved'
      await Leave.findByIdAndUpdate(req.params.id, { status: 'Approved' });
      res.redirect('/leave-status'); // Redirect to leave status page after approval
    } else {
      res.status(403).send('Unauthorized action');
    }
  } catch (err) {
    console.error('Error approving leave:', err);
    res.status(500).send('Error approving leave');
  }
});

// Reject leave route (for Director/HR only)
app.post('/reject-leave/:id', ensureAuthenticated, async (req, res) => {
  try {
    // Ensure the logged-in user is authorized to reject leaves (Director/HR)
    if (['Director', 'HR'].includes(req.user.position)) {
      const leave = await Leave.findById(req.params.id);
      if (!leave) {
        return res.status(404).send('Leave request not found');
      }

      // Update leave status to 'Rejected'
      await Leave.findByIdAndUpdate(req.params.id, { status: 'Rejected' });
      res.redirect('/leave-status'); // Redirect to leave status page after rejection
    } else {
      res.status(403).send('Unauthorized action');
    }
  } catch (err) {
    console.error('Error rejecting leave:', err);
    res.status(500).send('Error rejecting leave');
  }
});

// Define routes for authentication and leave functionality
app.use('/auth', authRoutes); // Authentication routes
app.use('/', leaveRoutes); // Leave management routes

// Homepage route
app.get('/homepage', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'homepage.html'));
});

// Login route
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

// Profile route (protected route)
app.get('/profile', ensureAuthenticated, (req, res) => {
  res.render('profile', { user: req.user });
});

// Database connection with better error handling
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/leavemanagement', { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
})
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((err) => {
    console.error('Error connecting to MongoDB', err);
    process.exit(1); // Exit process if DB connection fails
  });

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
