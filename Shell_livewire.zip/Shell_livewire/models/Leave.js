const mongoose = require('mongoose');

const leaveSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  employeeName: String,
  leaveType: String,
  startDate: Date,
  endDate: Date,
  status: { type: String, default: 'Pending' },
  reason: String, // New field for the reason of leave
  applicationDate: { type: Date, default: Date.now } // New field for storing application date
});

module.exports = mongoose.model('Leave', leaveSchema);
