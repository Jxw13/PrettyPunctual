const mongoose = require('mongoose');

const leaveSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  employeeName: String,
  leaveType: String,
  startDate: Date,
  endDate: Date,
  status: { type: String, default: 'Pending' },
  reason: String, 
  applicationDate: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Leave', leaveSchema);
