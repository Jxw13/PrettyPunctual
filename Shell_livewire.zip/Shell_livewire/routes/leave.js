const express = require('express');
const router = express.Router();
const Leave = require('../models/Leave');
const User = require('../models/User');

// Middleware to ensure only authorized users (Directors, Supervisors, Managers) can approve/reject
function ensureDirectorOrSupervisor(req, res, next) {
  if (['Director', 'Supervisor', 'Manager'].includes(req.user.position)) {
    return next(); // User is authorized to proceed
  }
  res.redirect('/login'); // Redirect to login if not authorized
}

// Middleware to ensure user is authenticated (for general leave status page)
async function ensureAuthenticated(req, res, next) {
  if (req.session && req.session.userId) {
    try {
      const user = await User.findById(req.session.userId);
      if (!user) {
        return res.redirect('/login'); // Redirect to login if user not found
      }
      req.user = user; // Attach user data to req.user
      next(); // Proceed to the next middleware or route handler
    } catch (err) {
      console.error('Error finding user:', err);
      return res.redirect('/login'); // Redirect to login in case of error
    }
  } else {
    res.redirect('/login'); // Redirect to login if no session
  }
}

// Route to display leave status for the logged-in user (or all for Directors/Supervisors)
router.get('/leave-status', ensureAuthenticated, async (req, res) => {
  let leaves;

  // Directors/Supervisors/Managers can see all leave applications
  if (['Director', 'Supervisor', 'Manager'].includes(req.user.position)) {
    leaves = await Leave.find({});
  } else {
    // Employees can only see their own leave applications
    leaves = await Leave.find({ userId: req.user._id });
  }

  // Render leave-status page with filtered leave data
  res.render('leave-status', { leaves, user: req.user });
});

// Apply leave route
router.post('/apply-leave', ensureAuthenticated, async (req, res) => {
  const { leaveType, startDate, endDate, reason } = req.body;

  // Fetch the user from the session
  const user = await User.findById(req.session.userId);

  const leave = new Leave({
    userId: user._id,
    employeeName: user.fullname, // Store the employee's name
    leaveType,
    startDate,
    endDate,
    reason,
    applicationDate: new Date()
  });

  await leave.save();
  res.redirect('/leave-status'); // Redirect to the leave status page after applying leave
});

// Approve leave route (for Director/Supervisor/Manager only)
router.post('/approve-leave/:id', ensureAuthenticated, ensureDirectorOrSupervisor, async (req, res) => {
  try {
    const leaveId = req.params.id;
    const leave = await Leave.findById(leaveId);
    if (!leave) {
      return res.status(404).send('Leave request not found');
    }

    // Approve the leave
    await Leave.findByIdAndUpdate(leaveId, { status: 'Approved' });
    res.redirect('/leave-status'); // Redirect to the leave status page after approval
  } catch (err) {
    console.error(err);
    res.status(500).send('Error approving leave');
  }
});

// Reject leave route (for Director/Supervisor/Manager only)
router.post('/reject-leave/:id', ensureAuthenticated, ensureDirectorOrSupervisor, async (req, res) => {
  try {
    const leaveId = req.params.id;
    const leave = await Leave.findById(leaveId);
    if (!leave) {
      return res.status(404).send('Leave request not found');
    }

    // Reject the leave
    await Leave.findByIdAndUpdate(leaveId, { status: 'Rejected' });
    res.redirect('/leave-status'); // Redirect to the leave status page after rejection
  } catch (err) {
    console.error(err);
    res.status(500).send('Error rejecting leave');
  }
});

module.exports = router;
