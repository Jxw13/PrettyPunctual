const express = require('express');
const router = express.Router();
const User = require('../models/User');
const path = require('path');
const bcrypt = require('bcrypt');

// Serve the signup page (GET request)
router.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, '../views/signup.html'));
});

// Signup route
router.post('/signup', async (req, res) => {
  const { fullname, email, phone, dob, department, position, password } = req.body;
  const user = new User({ fullname, email, phone, dob, department, position, password });
  await user.save();
  res.redirect('/login');
});

// Serve the login page (GET request)
router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../views/login.html'));
});

// Login route
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (user) {
    req.session.userId = user._id;  // Set the user ID in session
    req.user = user;
    res.redirect('/homepage');
  } else {
    res.send('Invalid login credentials');
  }
});

// Serve the homepage (GET request)
router.get('/homepage', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/login'); // Redirect if not logged in
  }
  res.sendFile(path.join(__dirname, '../views/homepage.html'));
});

// Profile route
router.get('/profile', async (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/login'); // Redirect to login if not authenticated
  }

  const user = await User.findById(req.session.userId);
  if (!user) {
    return res.redirect('/login');
  }

  // Render the profile page with user data
  res.render('profile', { user });
});

// Logout route
router.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.send('Error logging out');
    }
    res.redirect('/login');
  });
});

module.exports = router;
