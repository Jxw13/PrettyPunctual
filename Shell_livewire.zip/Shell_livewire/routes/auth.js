const express = require('express');
const router = express.Router();
const User = require('../models/User');
const path = require('path');
const bcrypt = require('bcrypt');

router.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, '../views/signup.html'));
});

router.post('/signup', async (req, res) => {
  const { fullname, email, phone, dob, department, position, password } = req.body;
  const user = new User({ fullname, email, phone, dob, department, position, password });
  await user.save();
  res.redirect('/login');
});

router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../views/login.html'));
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (user) {
    req.session.userId = user._id;  
    req.user = user;
    res.redirect('/homepage');
  } else {
    res.send('Invalid login credentials');
  }
});

router.get('/homepage', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/login'); 
  }
  res.sendFile(path.join(__dirname, '../views/homepage.html'));
});

// Profile route
router.get('/profile', async (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/login'); 
  }

  const user = await User.findById(req.session.userId);
  if (!user) {
    return res.redirect('/login');
  }
  
  res.render('profile', { user });
});

router.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.send('Error logging out');
    }
    res.redirect('/login');
  });
});

module.exports = router;
